import qrcode

generate_image = qrcode.make("Yash Malik linkedin")
generate_image.save('image1')